# CaC Setup
Open a linux terminal to enter the following commands. If you have not yet run sudo apt-get update you may get a pink screen during the last command of the Reinstall firefox section. This is normal. Continue through the pink screen and then reenter the final command once you have finished.

## Uninstall Firefox Snap
```shell
sudo snap remove --purge firefox
```

## Reinstall firefox
```shell
sudo install -d -m 0755 /etc/apt/keyrings
```

#### If you do not have wget run 
```shell
sudo apt-get install wget
```

```shell
wget -q https://packages.mozilla.org/apt/repo-signing-key.gpg -O- | sudo tee /etc/apt/keyrings/packages.mozilla.org.asc > /dev/null
```

```shell
echo "deb [signed-by=/etc/apt/keyrings/packages.mozilla.org.asc] https://packages.mozilla.org/apt mozilla main" | sudo tee -a /etc/apt/sources.list.d/mozilla.list > /dev/null
```

```shell
echo '
Package: *
Pin: origin packages.mozilla.org
Pin-Priority: 1000
' | sudo tee /etc/apt/preferences.d/mozilla
```

#### Reminder: This may give you a pink screen. If so please continue through that screen and then reneter the command

```shell
sudo apt-get update && sudo apt-get install firefox
```

## Run setup script

### <u>Ensure your CAC reader is connected (if external) and your CAC is not inserted</u>

Open the directory that you hvae the cacsetup.sh saved in your terminal

Example if cacsetup.sh is in my Downloads folder

```
cd ~/Downloads
```

```
chmod +x cacsetup.sh
```

```
sudo ./cacsetup.sh
```

## Test functionality
1) Browse to https://webmail.apps.mil/mail/ in firefox
2) Enter your socom.mil email address and click continue
3) Click on the 'Sign in with DOD CAC' link and enter your CAC pin
4) If you are not logged into outlook you may need to rerun the setup script again
